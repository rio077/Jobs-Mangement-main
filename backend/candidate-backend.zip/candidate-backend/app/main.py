from fastapi import FastAPI, File, UploadFile
from .routes import superadmin, register, team, jobs
from .routes import public

import cloudinary
import cloudinary.uploader

app = FastAPI(
    title="Candidate",
    description="Free Recruitment Career Site!🚀",
    version="0.0.1",
    docs_url="/api",
    redoc_url="/redoc",
    contact={
        "name": "API Details & Documentation",
        "url": "https://pending.com",
    },
)

tags_metadata = [
    {
        "name": "Registration",
        "description": "Operations with users. The **login** logic is also here.",
    },

]

app.include_router(superadmin.superadmin)
app.include_router(register.register)
app.include_router(jobs.jobs)
app.include_router(public.public)
app.include_router(team.team)


@app.get("/")
def read_root():
    return {"🚀": "Candidate Recruitmen is Live"}
