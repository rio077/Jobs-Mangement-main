from fastapi import FastAPI, APIRouter, UploadFile, File
from ..models.applications import ApplicationModel
from ..schema.publicSchema import get_Public, get_JobId, post_Apply, post_ApplyUploader
from typing import Optional


public = APIRouter()


@public.get("/public/getAllJobs/{orgKey}", tags=['Public'], summary="Public",)
def read_root(orgKey):
    """
    ### Get all jobs [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=get_Public(orgKey)
    return {"response":response}

@public.get("/public/getJob/{jobID}", tags=['Public'], summary="Public",)
def read_root(orgKey,jobId):
    """
    ### See details of specified job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=get_JobId(orgKey,jobId)
    return {"response":response}

@public.post("/public/apply", tags=['Public'], summary="Public",)
def read_root(orgKey,orgId,jobId,data:ApplicationModel):
    """
    ### Apply for a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Apply(orgKey,orgId,jobId,data)
    return {"response":response}

@public.post("/public/applyUploader", tags=['Public'], summary="Public")
def read_root(
    applicationId, 
    coverLetter: Optional[UploadFile] = File(None), 
    resume: Optional[UploadFile] = File(None)
):
    """
    ### Apply for a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response = post_ApplyUploader(applicationId, coverLetter, resume)
    return {"response": response}
