from fastapi import FastAPI, APIRouter
from ..models.user import TeamModel, VerifyEmailModel
from ..schema.team import post_Team, patch_VerifyEmail

team = APIRouter()


@team.get("/{company_ID/all}", tags=['Team'], summary="",)
def read_root():
    """
    ### Get list of team members & roles [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    return {"Message": "This is reply!"}

@team.get("/{company_ID/{user_ID}}", tags=['Team'], summary="",)
def read_root():
    """
    ### Get details of specific user [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    return {"Message": "This is reply!"}

@team.post("/{company_ID/add-member}", tags=['Team'], summary="",)
def read_root(data:TeamModel):
    """
    ### Get list of team members & roles [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Team(data)
    return {"response":response}

@team.patch("/company_ID/verifyEmail{emailToken}", tags=['Team'], summary="",)
def read_root(emailToken,data:VerifyEmailModel):
    """
    ### Get list of team members & roles [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=patch_VerifyEmail(emailToken,data)
    return {"response":response}


@team.patch("/{company_ID/update-member}", tags=['Team'], summary="",)
def read_root():
    """
    ### Get list of team members & roles [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    return {"Message": "This is reply!"}

@team.patch("/{company_ID/{user_ID}}", tags=['Team'], summary="",)
def read_root():
    """
    ### Get list of team members & roles [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    return {"Message": "This is reply!"}