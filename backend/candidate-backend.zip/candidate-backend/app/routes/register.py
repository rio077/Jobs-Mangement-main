from fastapi import FastAPI, APIRouter, Header
from ..models.user import Step1Model, Step2Model, Step3Models, Step4Models
from ..models.organization import OrganizationModel
from ..schema.registerSchema import post_Step1, post_Step2, post_Step3
from ..schema.registerSchema import post_Step4, post_UserSignIn, patch_userRegister


register = APIRouter()


@register.post("/user/sign-up/step-1", tags=['Register'], summary="Email & Password - Step 1",)
def read_root(data:Step1Model,xtoken: str | None = Header(None)):
    """
    ### UserEmail, Password, [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Step1(data,xtoken)
    return {"response":response}

@register.post("/user/sign-up/step-2", tags=['Register'], summary="Organization Info - Step 2",)
def read_root(userId,data:Step2Model,xtoken: str | None = Header(None)):
    """
    ###  Department, Organization Name, Country, Website, Desired Domain, No of Job posts, Team Members [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Step2(userId,data,xtoken)
    return {"response":response}

@register.post("/user/sign-up/step-3", tags=['Register'], summary="Service Required - Step 3",)
def read_root(userId,data:Step3Models,xtoken: str | None = Header(None)):
    """
    ### Services required list + Design Selection [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Step3(userId,data,xtoken)
    return {"response":response}

@register.post("/user/sign-up/step-4", tags=['Register'], summary="Personal Details - Step 4",)
def read_root(userId,data:Step4Models,xtoken: str | None = Header(None)):
    """
    ### First Name, Last Name, Designation, Mobile Number, Reffered By[Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Step4(userId,data,xtoken)
    return {"response":response}

@register.post("/user/login/{userEmail}", tags=['Register'], summary="User Login",)
def read_root(userEmail,password,xtoken: str | None = Header(None)):
    """
    ### Mobile Number, Password [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_UserSignIn(userEmail,password,xtoken)
    return {"response":response}

@register.patch("/user/update/{userID}", tags=['Register'], summary="Update Company Information",)
def read_root(userId,data:OrganizationModel,xtoken: str | None = Header(None)):
    """
    ### First Name, Last Name, Designation, Mobile Number, Reffered By[Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=patch_userRegister(userId,data,xtoken)
    return {"response":response}
