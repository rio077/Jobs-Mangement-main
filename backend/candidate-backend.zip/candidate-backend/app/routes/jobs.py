from fastapi import FastAPI, APIRouter, Header
from ..models.jobs import JobsModel
from ..models.applications import ApplicationStatusModel
from ..schema.jobsSchema import post_Jobs, get_Job, patch_Jobs
from ..schema.jobsSchema import delete_Jobs, post_Publish, get_JobApplication
from ..schema.jobsSchema import get_Job_SpecificApplication, get_UserApplicants, patch_ApplicantStatus
from fastapi_pagination import Page, add_pagination, paginate


jobs = APIRouter()


@jobs.post("/jobs/add", tags=['Jobs'], summary="Create Jobs",)
def read_root(data:JobsModel,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Add a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Jobs(data,organizationSecret,xtoken)
    return {"response":response}

@jobs.get("/jobs/get/{jobID}", tags=['Jobs'], summary="Get Jobs",)
def read_root(jobId,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Add a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=get_Job(jobId,organizationSecret,xtoken)
    return {"response":response}

@jobs.patch("/jobs/update/{jobID}", tags=['Jobs'], summary="Update Jobs",)
def read_root(jobId,data,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Update a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=patch_Jobs(jobId,data,organizationSecret,xtoken)
    return {"response":response}

@jobs.post("/jobs/publish", tags=['Jobs'], summary="Publish Job",)
def read_root(userId,jobId,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Add Publish [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_Publish(userId,jobId,organizationSecret,xtoken)
    return {"response":response}

@jobs.delete("/jobs/delete/{jobID}", tags=['Jobs'], summary="Delete Job",)
def read_root(jobId,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Delete Job- Soft Delete [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=delete_Jobs(jobId,organizationSecret,xtoken)
    return {"response":response}

@jobs.get("/jobs/getApplications/{orgID}", tags=['Jobs'], summary="Get Job,s Applications",)
def read_root(orgId,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Add a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=get_JobApplication(orgId,organizationSecret,xtoken)
    return {"response":response}

@jobs.get("/jobs/getJobApplications/{orgID}/{jobID}", tags=['Jobs'], summary="Get Specific Job's Applications",)
def read_root(orgId,jobId,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Add a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=get_Job_SpecificApplication(orgId,jobId,organizationSecret,xtoken)
    return {"response":response}

@jobs.get("/jobs/getApplicats/{applicantID}", tags=['Jobs'], summary="Get Specific Job's Applications",)
def read_root(applicantId,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Add a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=get_UserApplicants(applicantId,organizationSecret,xtoken)
    return {"response":response}

@jobs.patch("/jobs/applicantStatus/{applicantID}", tags=['Jobs'], summary="Update Jobs",)
def read_root(applicantId,data:ApplicationStatusModel,organizationSecret,xtoken: str | None = Header(None)):
    """
    ### Update a job [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=patch_ApplicantStatus(applicantId,data,organizationSecret,xtoken)
    return {"response":response}

add_pagination(jobs)