from fastapi import APIRouter
from ..models.superAdmin import SuperAdminModel
from ..schema.superAdminSchema import post_SuperAdmin, post_SuperAdminSignIn
from ..schema.superAdminSchema import get_SuperAdmin, patch_SuperAdmin

superadmin = APIRouter()


@superadmin.post("/superadmin/add", tags=['Superadmin'], summary="Add new superadmin",)
def read_root(data:SuperAdminModel):
    """
    ### Add New Superadmin with email, firstName, lastName, password, mobile [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_SuperAdmin(data)
    return {"response":response}

@superadmin.post("/superadmin/login", tags=['Superadmin'], summary="Login Superadmin",)
def read_root(superAdminEmail,superAdminPassword):
    """
    ### Add New Superadmin with email, firstName, lastName, password, mobile [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=post_SuperAdminSignIn(superAdminEmail,superAdminPassword)
    return {"response":response}

@superadmin.get("/superadmin/get/{superAdminID}", tags=['Superadmin'], summary="Get My Details",)
def read_root(superAdminID):
    """
    ### Get my details [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=get_SuperAdmin(superAdminID)
    return {"response":response}

@superadmin.patch("/superadmin/update/{superAdminID}", tags=['Superadmin'], summary="Update Superadmin Details",)
def read_root(superAdminID,data):
    """
    ### Update my details [Documentation Here](https://docs.google.com/document/d/11b0gBImZmHH_FCxeZxtvVJ7UF7VAcB3EF_KKSIIjEmo/edit#heading=h.4fpya9hkk4bs) 
    """
    response=patch_SuperAdmin(superAdminID,data)
    return {"response":response}