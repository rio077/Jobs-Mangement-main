from ..models import jobs
from ..config.db import jobss, userRegistration, organization, application, x_token_env, orgKey
from bson.objectid import ObjectId
import json
from datetime import datetime, date

from fastapi_pagination import Page, add_pagination, paginate


def post_Jobs(data,secretKey,xToken):
    data=dict(data)
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            userI=userRegistration.find_one({"_id":ObjectId(data["postedBy"])})
            if userI:
                jobss.insert_one(data)
                jobss.update_one({"_id":ObjectId(data["_id"])},{"$set":{"isJobPublished.published":bool(False)}})
                jobss.update_one({"_id":ObjectId(data["_id"])},{"$set":{"isJobPublished.approvedBy":str("")}})
                jobss.update_one({"_id":ObjectId(data["_id"])},{"$set":{"isJobDeleted":bool(False)}})
                return "Job Details added"
            else:
                return "User ID not found"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"
    
def get_Job(jobId,secretKey,xToken):
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            job=jobss.find_one({"_id":ObjectId(jobId)})
            if job:
                job["_id"]=str(job["_id"])
                return job
            else:
                return "Job ID not found"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"
    
def patch_Jobs(jobId,data,secretKey,xToken):
    data=json.loads(data)
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            job=jobss.find_one({"_id":ObjectId(jobId)})
            if job:
                jobss.update_one({"_id":ObjectId(jobId)},{"$set":data})
                return "Job's details has been updated"
            else:
                return "Job not found"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"
    
def post_Publish(userId,jobId,secretKey,xToken):
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            userI=userRegistration.find_one({"_id":ObjectId(userId)})
            jobI=jobss.find_one({"_id":ObjectId(jobId)})
            if userI:
                if jobI:
                    jobss.update_one({"_id":ObjectId(jobId)},{"$set":{"isJobPublished.published":bool(True)}})
                    jobss.update_one({"_id":ObjectId(jobId)},{"$set":{"isJobPublished.approvedBy":ObjectId(userId)}})
                    jobss.update_one({"_id":ObjectId(jobId)},{"$set":{"isJobPublished.createdOn":datetime.now()}})
                    return "Job Published"
                else:
                    return "Job ID not found"
            else:
                return "User ID not found"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"
                
def delete_Jobs(jobId,secretKey,xToken):
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            job=jobss.find_one({"_id":ObjectId(jobId)})
            if job:
                jobss.update_one({"_id":ObjectId(jobId)},{"$set":{"isJobDeleted":bool(True)}})
                return "Job has been deleted"
            else:
                return "Job ID not found"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"
    
def get_JobApplication(orgId,secretKey,xToken):
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            job = []
            org = organization.find_one({"_id": ObjectId(orgId)})
            if org:
                for j in org["jobsPosted"]:
                    jobAppli = application.find_one({"jobId": ObjectId(j)})
                    if jobAppli:
                        jobAppli = {k: str(v) if isinstance(v, ObjectId) else v for k, v in jobAppli.items()}
                        id=str(jobAppli["_id"])
                        firstName=str(jobAppli["firstName"])
                        lastName=str(jobAppli["lastName"])
                        applied=str(jobAppli["ctreatedOn"])
                        applicantDetails={"_id":id,"firstName":firstName,"lastName":lastName,"appliedOn":applied}
                        job.append(applicantDetails)
                return job
            else:
                return "Invalid Organization ID"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"
    
def get_Job_SpecificApplication(orgId,jobId,secretKey,xToken):
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            job = []
            org = organization.find_one({"_id": ObjectId(orgId)})
            if org:
                specificJob= jobss.find_one({"_id": ObjectId(jobId)})
                if specificJob:
                    for j in org["jobsPosted"]:
                        jobAppli = application.find_one({"jobId": ObjectId(j)})
                        if jobAppli:
                            jobAppli = {k: str(v) if isinstance(v, ObjectId) else v for k, v in jobAppli.items()}
                            id=str(jobAppli["_id"])
                            firstName=str(jobAppli["firstName"])
                            lastName=str(jobAppli["lastName"])
                            applied=str(jobAppli["ctreatedOn"])
                            applicantDetails={"_id":id,"firstName":firstName,"lastName":lastName,"appliedOn":applied}
                            job.append(applicantDetails)
                    return job
                else:
                    return "This Job ID does not belongs to this Organzation"
            else:
                return "Invalid Organization ID"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"
    
def get_UserApplicants(applicantId,secretKey,xToken):
    if xToken==x_token_env:
        if secretKey==orgKey:
        # if organization.find_one({"orgKey":secretKey}):
            job = []
            appli = application.find_one({"_id": ObjectId(applicantId)})
            if appli:
                appli["_id"]=str(appli["_id"])
                appli["orgId"]=str(appli["orgId"])
                appli["jobId"]=str(appli["jobId"])
                return appli
            else:
                return "Invalid Application ID"
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"

def patch_ApplicantStatus(applicantId,data,secretKey,xToken):
    data=dict(data)
    if xToken==x_token_env:
        if secretKey==orgKey:
            # if organization.find_one({"orgKey":secretKey}):
            appli=application.find_one({"_id":ObjectId(applicantId)})
            if appli:
                if data["status"]=="Reject":
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusRejected":data}})
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusRejected.statusDate":datetime.now()}})
                    return "Details Patched"
                elif data["status"]=="Review":
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusReview":data}})
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusReview.statusDate":datetime.now()}})
                    return "Details Patched"
                elif data["status"]=="Applied":
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusApplied":data}})
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusApplied.statusDate":datetime.now()}})
                    return "Details Patched"
                elif data["status"]=="Schedule":
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusSchedule":data}})
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusSchedule.statusDate":datetime.now()}})
                    return "Details Patched"
                elif data["status"]=="Interview":
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusInterview":data}})
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusInterview.statusDate":datetime.now()}})
                    return "Details Patched"
                elif data["status"]=="Offer":
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusOffer":data}})
                    application.update_one({"_id":ObjectId(applicantId)},{"$set":{"statusOffer.statusDate":datetime.now()}})
                    return "Details Patched"
            else:
                return "Invalid Applicant ID" 
        else:
            return "Invalid Organization Key"
    else:
        return "Invalid xToken!!"           
    
    
    