from ..models import jobs
from ..config.db import userRegistration
from bson.objectid import ObjectId
import json
from datetime import datetime, date
import secrets


def post_Team(data):
    data=dict(data)
    if data["role"]=="Admin" or data["role"]=="Manager" or data["role"]=="HR" or data["role"]=="Technical":
        userRegistration.insert_one(data)
        userRegistration.update_one({"_id":ObjectId(data["_id"])},{"$set":{"emailToken":secrets.token_hex(8)}})
        userRegistration.update_one({"_id":ObjectId(data["_id"])},{"$set":{"mobileNumberToken":""}})
        return "Team member added successfully"
    else:
        return "Please enter valid role"
    
def patch_VerifyEmail(emailT,data):
    data=dict(data)
    userToken=userRegistration.find_one({"emailToken":emailT})
    if userToken:
        userRegistration.update_one({"emailToken":emailT},{"$set":data})
        userRegistration.update_one({"emailToken":emailT},{"$unset":{"emailToken":""}})
        return "Password created"
    else:
        return "Invalid email token"
    
    