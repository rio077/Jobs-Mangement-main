from ..models import user
from ..config.db import userRegistration, organization, domain, x_token_env
from bson.objectid import ObjectId
import json
from datetime import datetime, date
from random import randint

from ..auth.jwt_handler import signJWT
from ..auth.jwt_berear import jwtBearer

import secrets 


def post_Step1(data,xToken):
    data=dict(data)
    if xToken==x_token_env:
        # if organization.find_one({"orgKey":secretKey}):
            userRegistration.insert_one(data)
            # userRegistration.update_one({"_id":ObjectId(data["_id"])},{"$set":{"emailToken":""}})
            return "Step 1 completed"
    else:
        return "Invalid xToken!!"

def post_Step2(userId,data,xToken):
    data=dict(data)
    if xToken==x_token_env:
        # if organization.find_one({"orgKey":secretKey}):
            userI=userRegistration.find_one({"_id":ObjectId(userId)})
            if userI:
                userRegistration.update_one({"_id":ObjectId(userId)},{"$set":{"role":"Admin"}})
                userRegistration.update_one({"_id":ObjectId(userId)},{"$set":{"department":data["department"]}})
                userRegistration.update_one({"_id":ObjectId(userId)},{"$set":{"createdOn":datetime.now()}})
                userRegistration.update_one({"_id":ObjectId(userId)},{"$set":{"isApproved":bool(False)}})
                
                
                orgForId=organization.insert_one({"userId":ObjectId(userId)})
                organization.update_one({"userId":ObjectId(userId)},{"$set":{"orgLegalName":data["orgName"]}})
                organization.update_one({"userId":ObjectId(userId)},{"$set":{"locationDetails.country":data["country"]}})
                organization.update_one({"userId":ObjectId(userId)},{"$set":{"orgWebsite":data["website"]}})
                organization.update_one({"userId":ObjectId(userId)},{"$set":{"desiredDomain":data["desiredDomain"]}})
                
                
                organization.update_one({"userId":ObjectId(userId)},{"$set":{"orgKey":secrets.token_hex(12)}})
                
                
                userRegistration.update_one({"_id":ObjectId(userId)},{"$set":{"orgId":orgForId.inserted_id}})

                
                domain.insert_one({"orgId":orgForId.inserted_id})
                domain.update_one({"userId":userId},{"$set":{"desiredDomainName":data["desiredDomain"]}})
                
                return "Step 2 completed"
            else:
                return "User ID not found"
    else:
        return "Invalid xToken!!"

def post_Step3(userId,data,xToken):
    data=dict(data)
    if xToken==x_token_env:
        # if organization.find_one({"orgKey":secretKey}):
            userI=userRegistration.find_one({"_id":ObjectId(userId)})
            if userI:        
                organization.update_one({"userId":ObjectId(userId)},{"$set":{"servicesRequired":data["servicesRequired"]}})
                organization.update_one({"userId":ObjectId(userId)},{"$set":{"designLayout":data["designLayout"]}})
                return "Step 3 completed"
            else:
                return "User ID not found"
    else:
        return "Invalid xToken!!"
    
def post_Step4(userId,data,xToken):
    data=dict(data)
    if xToken==x_token_env:
        # if organization.find_one({"orgKey":secretKey}):
            userI=userRegistration.find_one({"_id":ObjectId(userId)})
            if userI:
                affilatedId=(data["userFirstName"]+str(randint(100, 999))).lower()
                userRegistration.update_one({"_id":ObjectId(userId)},{"$set":data})
                # userRegistration.update_one({"_id":ObjectId(userId)},{"$set":{"mobileNumberToken":""}})
                userRegistration.update_one({"_id":ObjectId(userId)},{"$set":{"affiliatedId":affilatedId}})
                return "Step 4 completed"
            else:
                return "User ID not found"
    else:
        return "Invalid xToken!!"
    
def post_UserSignIn(userEmail,password,xToken):
    if xToken==x_token_env:
        # if organization.find_one({"orgKey":secretKey}):
            if userRegistration.find_one({"userEmail":str(userEmail)}):
                if userRegistration.find_one({"userPassword":str(password)}):
                    return "Successfully Logined"
                    #Later For JWT Authentication
                    # return signJWT(superAdminEmail)
                else:
                    return "Invalid Password"
            else:
                return "Invalid Mobile Number" 
    else:
        return "Invalid xToken!!"
    
def patch_userRegister(userId,data,xToken):
    data=dict(data)
    if xToken==x_token_env:
        # if organization.find_one({"orgKey":secretKey}):
            userI=userRegistration.find_one({"_id":ObjectId(userId)})
            if userI:        
                organization.update_one({"userId":ObjectId(userId)},{"$set":data})
                return "Organiztion Details Patched"
            else:
                return "User ID not found"
    else:
        return "Invalid xToken!!"
    
    

    