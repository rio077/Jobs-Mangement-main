from ..models import superAdmin
from ..config.db import superAdmin
from bson.objectid import ObjectId
import json
from datetime import datetime, date

from ..auth.jwt_handler import signJWT
from ..auth.jwt_berear import jwtBearer

def post_SuperAdmin(data):
    data=dict(data)
    if(data["role"]=="HR" or data["role"]=="Super Admin"):
        superAdmin.insert_one(data)
        superAdmin.update_one({"email":data["email"]},{"$set":{"createdOn":datetime.now()}})
        superAdmin.update_one({"email":data["email"]},{"$set":{"isDeleted":True}})
        return "SuperAdmin Signup has been created"
    else:
        return "Please enter valid SuperAdmin Role"

def post_SuperAdminSignIn(superAdminEmail,password):
    if superAdmin.find_one({"email":str(superAdminEmail)}):
        if superAdmin.find_one({"password":str(password)}):
            return "Successfully Logined"
            #Later For JWT Authentication
            # return signJWT(superAdminEmail)
        else:
            return "Invalid Password"
    else:
        return "Invalid Email"  
    
def get_SuperAdmin(superAdminId):
    superA=superAdmin.find_one({"_id":ObjectId(superAdminId)})
    if superA:
        superA["_id"]=str(superA["_id"])
        return superA
    else:
        return "Super Admin ID not found"
    
def patch_SuperAdmin(superAdminID,data):
    data=json.loads(data)
    superA=superAdmin.find_one({"_id":ObjectId(superAdminID)})
    if superA:
        superAdmin.update_one({"_id":ObjectId(superAdminID)},{"$set":data})
        return "Super Admin's details has been updated"
    else:
        return "Super Admin not found"