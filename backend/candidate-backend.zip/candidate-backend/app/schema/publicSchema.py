from ..models import jobs
from ..config.db import jobss, organization, userRegistration, application
from bson.objectid import ObjectId
import json
from datetime import datetime, date

import cloudinary
import cloudinary.uploader


def get_Public(orgK):
    job = []
    lst = []
    org = organization.find_one({"orgKey": orgK})
    if org:
        for jobId in org["jobsPosted"]:
            job = jobss.find_one({"_id": ObjectId(jobId)})
            if job:
                if job["isJobPublished"]["published"] == True and job["isJobDeleted"] == False:
                    id = str(job["_id"])
                    title = job["jobTitle"]
                    mode = job["jobModeLocation"]
                    location = job["jobLocation"]
                    displayItems = {"_id": id, "jobTitle": title, "jobModeLocation": mode, "jobLocation": location}
                    lst.append(displayItems)
                else:
                    return "No new job opening"
            else:
                return "No Job Found"
        return lst
    else:
        return "Invalid organization key"
    
def get_JobId(orgK,jobId):
    org = organization.find_one({"orgKey": orgK})
    if org:
        jobsId=jobss.find_one({"_id":ObjectId(jobId)})
        if jobsId:
            jobsId["_id"]=str(jobsId["_id"])
            return jobsId
        else:
            return "Job ID not found"
    else:
        return "Invalid organization key"
    
def post_Apply(orgKey,orgId,jobId,data):
    data=dict(data)
    org=organization.find_one({"_id":ObjectId(orgId)} and {"orgKey":str(orgKey)} and {"jobsPosted":str(jobId)})
    if org:
        job=jobss.find_one({"_id":ObjectId(jobId)})
        if job:
            application.insert_one({"email":data["email"]})
            application.update_one({"email":data["email"]},{"$set":{"firstName":data["firstName"]}})
            application.update_one({"email":data["email"]},{"$set":{"lastName":data["lastName"]}})
            application.update_one({"email":data["email"]},{"$set":{"mobileNumber":data["mobileNumber"]}})
            application.update_one({"email":data["email"]},{"$set":{"orgId":ObjectId(orgId)}})
            application.update_one({"email":data["email"]},{"$set":{"jobId":ObjectId(jobId)}})
            
            
            if job["requireList"]["linkedIn"]==True:
                application.update_one({"email":data["email"]},{"$set":{"linkedIn":data["linkedIn"]}})
            if job["requireList"]["github"]==True:
                application.update_one({"email":data["email"]},{"$set":{"github":data["github"]}})
                
            # if job["requireList"]["coverLetter"]==True:
            #     application.update_one({"_id":ObjectId(dataId["_id"])},{"$set":{"coverLetter":data["coverLetter"]}})
            # if job["requireList"]["resume"]==True:
            #     application.update_one({"_id":ObjectId(dataId["_id"])},{"$set":{"resume":data["resume"]}})
                
            if job["requireList"]["reference"]==True:
                application.update_one({"email":data["email"]},{"$set":{"reference":data["reference"]}})
            if job["requireList"]["behance"]==True:
                application.update_one({"email":data["email"]},{"$set":{"behance":data["behance"]}})
            if job["requireList"]["portfolio"]==True:
                application.update_one({"email":data["email"]},{"$set":{"portfolio":data["portfolio"]}})
            
            application.update_one({"email":data["email"]},{"$set":{"ctreatedOn":datetime.now()}})   
            return "applied"
        else:
            return "Job ID not found"
    else:
        return "user ID not found"
            
def post_ApplyUploader(appId,coverLetter,resume):
    user=application.find_one({"_id":ObjectId(appId)})
    if user:
        job=jobss.find_one({"_id":ObjectId(user["jobId"])})
        if job["requireList"]["coverLetter"]==True:
            result = cloudinary.uploader.upload(coverLetter.file)
            url = result.get("url")
            application.update_one({"_id":ObjectId(appId)},{"$set":{"coverLetter":str(url)}})
                     
        if job["requireList"]["resume"]==True:
            result = cloudinary.uploader.upload(resume.file)
            url = result.get("url")
            application.update_one({"_id":ObjectId(appId)},{"$set":{"resume":str(url)}})
        return "Files uploaded"
    
    else:
        return "Application ID not found"

                     
            

                
    
    