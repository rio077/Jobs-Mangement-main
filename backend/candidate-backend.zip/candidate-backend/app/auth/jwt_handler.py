#This file is responsible for-
#signing, encoding, decoding and returning JWTs

import time
import jwt

SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

#Function returns the generated Tokens
def token_response(token: str):
    return{
        "access token":token
    }
#Function used for signing the JWT  string
def signJWT(userID: str):
    payload={
        "userID": userID,
        "expiry": time.time() +600
    }
    token= jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    return token_response(token)

#Function to decode Token
def decodeJWT(token: str):
    try:
        decode_token= jwt.decode(token, SECRET_KEY, algorithm=ALGORITHM)
        return decode_token if decode_token['expires']>=time.time() else None
    except:
        return {}