from pydantic import BaseModel, EmailStr
from datetime import datetime

class JobTemplateModel(BaseModel):
    sector: str
    jobTitle: str
    deparmentId: str
    departmentName: str
    jobTitle: str
    jobDescription: str
    jobSummary: str
    jobBriefing: str
    jobDescription: dict
    jobQualifications: dict
    jobRequirements: dict
    jobBenefits: dict
    jobType: list
    requireList: dict = {
        "linkedin": "", 
        "github": "", 
        "coverLetter": "", 
        "resume": "", 
        "reference": "", 
        "behance": "", 
        "portfolio": False
    }
    skillsRequired: list
    toolsRequired: list
    
    