from pydantic import BaseModel, EmailStr, Field

class SuperAdminModel(BaseModel):
    fullName: str
    email: EmailStr
    password: str
    mobile: int
    role: str