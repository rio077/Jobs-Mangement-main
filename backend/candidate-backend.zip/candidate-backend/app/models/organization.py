from pydantic import BaseModel, EmailStr
from datetime import datetime

class OrganizationModel(BaseModel):
    # userId: str
    orgInformation: str
    # orgLegalName: str
    # orgWebsite: str
    # desiredDomain: str
    orgStage:str
    sector: str
    subSector: list
    locationDetails: dict = {
        "address": "",
        "city": ""
    }
    orgSize: str
    urlLink: str
    socialLinks: str
    orgUsers: list
    jobsPosted: list
    orgNotes: dict = {
        "notesAssociated": "", 
        "message": "", 
        "superAdminName": "", 
        "createdAt": datetime.now()
    }