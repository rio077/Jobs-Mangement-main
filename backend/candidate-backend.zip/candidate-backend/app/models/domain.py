from pydantic import BaseModel, EmailStr
from datetime import datetime

class DomainModel(BaseModel):
    orgId: str
    userId: str
    desiredDomainName: str
    ourDomainName: str
    deploymentStatus: bool
    deploymentPlatform: str
    ourDnsUpdateStatus: list
    clientDnsUpdateStatus: bool
    clintErrorMessage: str
    isErrorResolved: bool