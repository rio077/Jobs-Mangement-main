from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional

class ApplicationModel(BaseModel):
    # jobId: str
    # userId: str
    firstName: str
    lastName: str
    email: EmailStr
    mobileNumber: int
    linkedIn: Optional[str]
    github: Optional[str]
    # coverLetter: Optional[str]
    # resume: Optional[str]
    reference: Optional[str]
    behance: Optional[str]
    portfolio: Optional[str]
    
class ApplicationStatusModel(BaseModel):
        status: str
        personId: str
        comment: str
    
    