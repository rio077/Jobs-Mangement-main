from pydantic import BaseModel, EmailStr
from datetime import datetime

class DepartmentTemplateModel(BaseModel):
    departmentName: str
    departmentShortName: str
    isDeleted: bool