from pydantic import BaseModel, EmailStr
from datetime import datetime

class UserModel(BaseModel):
    userEmail: EmailStr
    userPassword: str
    userFirstName: str
    userLastName: str
    designation: str
    mobileNumber: int
    department: str
    refferedBy: str
    # affiliatedId: 
    orgId: str
    createdOn:datetime
    isApproved: bool
    adminComments: str
    
class Step1Model(BaseModel):
    userEmail: EmailStr
    userPassword: str
    
class Step2Model(BaseModel):
    department: str
    orgName: str
    country: str
    website: str
    desiredDomain: str
    # numberOfJobsPosts: int
    
class Step3Models(BaseModel):
    servicesRequired: dict = {
        "jobPostRequired": 0, 
        "ats": False, 
        "refferalModule": False, 
        "quickRecruitment": False, 
        "aiMatchRecommendation": False, 
        "organizationManagement": False
    }
    designLayout: str
    
class Step4Models(BaseModel):
    userFirstName: str
    userLastName: str
    designation: str
    mobileNumber: int
    
class TeamModel(BaseModel):
    userEmail: EmailStr
    mobileNumber: int
    userFirstName: str
    userLastName: str
    role: str

class VerifyEmailModel(BaseModel):
    userPassword: str
    

    