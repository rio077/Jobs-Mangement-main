from pydantic import BaseModel, EmailStr
from datetime import datetime

class ToolsTemplateModel(BaseModel):
    id: str