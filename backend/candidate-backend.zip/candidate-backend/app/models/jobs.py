from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional

class JobsModel(BaseModel):
    postedBy: str
    jobTitle: str
    jobDescription: str
    jobSummary:str
    jobBriefing: Optional[str]
    jobDescription: str
    jobQualifications: Optional[str]
    jobRequirements: Optional[str]
    jobBenifits: Optional[str]
    jobType: list
    internshipDetails: Optional[dict] = {
        "isPaid": False, 
        "prePlacementOffer": False, 
        "certificate": "", 
        "perks": "" 
    }
    jobModeLocation: str
    jobLocation: Optional[str]
    salaryDetails: dict ={
        "minimum": 0.0,
        "maximum": 0.0,
        "currency": ""
    }
    esopDetails: Optional[dict] = {
        "esopIsOffered": False,
        "esopDetails": ""
    }
    requireList: dict = {
        "linkedIn": False,
        "github": False,
        "coverLetter": False,
        "resume": False,
        "reference": False,
        "behance": False,
        "portfolio": False
    }
    statementList: dict = {
        "poshStatement": False,
        "ediStatement": False,
        "dataPrivacyStatement": False,
        "consentStatement": False
    }
    acceptFresher: Optional[bool] = False
    selfAttested: Optional[bool] = False
    status: Optional[str]
    applyLastDate: Optional[datetime]
    manager: str
    