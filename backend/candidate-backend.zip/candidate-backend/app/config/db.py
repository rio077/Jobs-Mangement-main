import pymongo, cloudinary

mongoURI="mongodb+srv://musu:Musu17Hanu@cluster0.hrsqgub.mongodb.net/temp"
client=pymongo.MongoClient(mongoURI)
x_token_env="1"
orgKey="1"
db=client["candidate"]

superAdmin=db["SuperAdmin"]
userRegistration=db["userRegistration"]
organization=db["Organization"]
domain=db["domain"]
jobss=db["jobs"]
application=db["application"]

cloudinary.config(
  cloud_name = "dwpjitown",
  api_key = "427843121278645",
  api_secret = "eubGg5OHrF1YmcU4xxcaz2ZQfJU",
  secure = True
)

